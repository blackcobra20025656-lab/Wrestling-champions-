WRESTLING CHAMPIONS - ANDROID APP PROJECT

This packages the playable Wrestling Champions web prototype inside a native Android WebView.

Build with Android Studio:
1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/.

For a Play Store release, create a signed release build in Android Studio.

Note: This project is a prototype and uses original characters/branding. It is not affiliated with WWE or other wrestling promotions.
